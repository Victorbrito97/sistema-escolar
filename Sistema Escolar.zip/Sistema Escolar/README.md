# Sistema Escolar - UI JavaFX mínima

Proyecto de ejemplo con JavaFX, MariaDB (JDBC) y JSch (placeholder). Contiene una ventana con 4 vistas: Persona, Materias, Inscripciones y Asistencias. Cada vista permite insertar registros y ver los ya existentes en un área de texto.

Requisitos
- JDK 17+
- Maven
- MariaDB (o MySQL compatible)

Configuración de la base de datos
1. Edite `src/main/java/com/sistemaescolar/db/DBConnection.java` y ajuste la URL, usuario y contraseña.
2. Cree la base de datos y tablas ejecutando el script `src/main/resources/db/schema.sql` en su servidor MariaDB:

   -- Usar cliente MariaDB o Workbench para ejecutar el script

Cómo ejecutar (desde Windows cmd.exe)
1. En una terminal, sitúese en la carpeta del proyecto (la que contiene `pom.xml`).
2. Compilar y ejecutar con el plugin JavaFX:

```
mvn clean javafx:run
```

Notas
- La dependencia `jsch` se incluye como placeholder para tareas SSH/SFTP; no hay integración funcional en esta versión inicial.
- Los DAOs usan JDBC directo y no realizan validaciones sofisticadas; están pensados como punto de partida.

Próximos pasos sugeridos
- Añadir validaciones en la UI (campos obligatorios, tipos numéricos).
- Añadir listados en tablas (TableView) en lugar de TextArea.
- Implementar autenticación y roles, y uso real de JSch si se requiere backup por SFTP.
