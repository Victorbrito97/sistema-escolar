package com.sistemaescolar.model;

import java.time.LocalDate;

public class Inscripcion {
    private Integer id;
    private Integer personaId;
    private Integer materiaId;
    private LocalDate fecha;

    public Inscripcion() {}

    public Inscripcion(Integer id, Integer personaId, Integer materiaId, LocalDate fecha) {
        this.id = id; this.personaId = personaId; this.materiaId = materiaId; this.fecha = fecha;
    }

    public Inscripcion(Integer personaId, Integer materiaId, LocalDate fecha) { this(null, personaId, materiaId, fecha); }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Integer getPersonaId() { return personaId; }
    public void setPersonaId(Integer personaId) { this.personaId = personaId; }
    public Integer getMateriaId() { return materiaId; }
    public void setMateriaId(Integer materiaId) { this.materiaId = materiaId; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    @Override
    public String toString() { return String.format("%d: persona=%d materia=%d fecha=%s", id==null?0:id, personaId, materiaId, fecha); }
}
