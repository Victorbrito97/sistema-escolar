package com.sistemaescolar.model;

import java.time.LocalDate;

public class Persona {
    private Integer id;
    private String nombre;
    private String apellido;
    private String sexo;
    private LocalDate fechaNacimiento;
    private String rol;

    public Persona() {}

    public Persona(Integer id, String nombre, String apellido, String sexo, LocalDate fechaNacimiento, String rol) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.rol = rol;
    }

    public Persona(String nombre, String apellido, String sexo, LocalDate fechaNacimiento, String rol) {
        this(null, nombre, apellido, sexo, fechaNacimiento, rol);
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    @Override
    public String toString() {
        return String.format("%d: %s %s | %s | %s | %s", id == null ? 0 : id, nombre, apellido, sexo, fechaNacimiento, rol);
    }
}
