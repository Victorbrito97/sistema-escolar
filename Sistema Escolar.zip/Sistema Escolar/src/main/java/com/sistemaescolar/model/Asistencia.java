package com.sistemaescolar.model;

import java.time.LocalDate;

public class Asistencia {
    private Integer id;
    private Integer inscripcionId;
    private LocalDate fecha;
    private boolean presente;

    public Asistencia() {}

    public Asistencia(Integer id, Integer inscripcionId, LocalDate fecha, boolean presente) {
        this.id = id; this.inscripcionId = inscripcionId; this.fecha = fecha; this.presente = presente;
    }

    public Asistencia(Integer inscripcionId, LocalDate fecha, boolean presente) { this(null, inscripcionId, fecha, presente); }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Integer getInscripcionId() { return inscripcionId; }
    public void setInscripcionId(Integer inscripcionId) { this.inscripcionId = inscripcionId; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public boolean isPresente() { return presente; }
    public void setPresente(boolean presente) { this.presente = presente; }

    @Override
    public String toString() { return String.format("%d: inscripcion=%d fecha=%s presente=%s", id==null?0:id, inscripcionId, fecha, presente); }
}
