package com.sistemaescolar.dao;

import com.sistemaescolar.db.DBConnection;
import com.sistemaescolar.model.Persona;
import java.util.ArrayList;
import java.util.List;

public class PersonaDAO {

    public void insert(Persona p) throws SQLException {
        String sql = "INSERT INTO persona_escuela(nombre, apellido, sexo, fecha_nacimiento, rol) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellido());
            ps.setString(3, p.getSexo());
            ps.setDate(4, Date.valueOf(p.getFechaNacimiento()));
            ps.setString(5, p.getRol());
            ps.executeUpdate();
        }
    }

    public List<Persona> listAll() throws SQLException {
        List<Persona> out = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido, sexo, fecha_nacimiento, rol FROM persona_escuela ORDER BY id";
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                Persona p = new Persona(rs.getInt("id"), rs.getString("nombre"), rs.getString("apellido"), rs.getString("sexo"), rs.getDate("fecha_nacimiento").toLocalDate(), rs.getString("rol"));
                out.add(p);
            }
        }
        return out;
    }
}
