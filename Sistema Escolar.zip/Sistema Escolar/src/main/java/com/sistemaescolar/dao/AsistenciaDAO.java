package com.sistemaescolar.dao;

import com.sistemaescolar.db.DBConnection;
import com.sistemaescolar.model.Asistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AsistenciaDAO {
    public void insert(Asistencia a) throws SQLException {
        String sql = "INSERT INTO asistencias(inscripcion_id, fecha, presente) VALUES (?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, a.getInscripcionId());
            ps.setDate(2, Date.valueOf(a.getFecha()));
            ps.setBoolean(3, a.isPresente());
            ps.executeUpdate();
        }
    }

    public List<Asistencia> listAll() throws SQLException {
        List<Asistencia> out = new ArrayList<>();
        String sql = "SELECT id, inscripcion_id, fecha, presente FROM asistencias ORDER BY id";
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                out.add(new Asistencia(rs.getInt("id"), rs.getInt("inscripcion_id"), rs.getDate("fecha").toLocalDate(), rs.getBoolean("presente")));
            }
        }
        return out;
    }
}
