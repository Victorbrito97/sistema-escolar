package com.sistemaescolar.dao;

import com.sistemaescolar.db.DBConnection;
import com.sistemaescolar.model.Inscripcion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InscripcionDAO {
    public void insert(Inscripcion i) throws SQLException {
        String sql = "INSERT INTO inscripciones(persona_id, materia_id, fecha) VALUES (?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, i.getPersonaId());
            ps.setInt(2, i.getMateriaId());
            ps.setDate(3, Date.valueOf(i.getFecha()));
            ps.executeUpdate();
        }
    }

    public List<Inscripcion> listAll() throws SQLException {
        List<Inscripcion> out = new ArrayList<>();
        String sql = "SELECT id, persona_id, materia_id, fecha FROM inscripciones ORDER BY id";
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                out.add(new Inscripcion(rs.getInt("id"), rs.getInt("persona_id"), rs.getInt("materia_id"), rs.getDate("fecha").toLocalDate()));
            }
        }
        return out;
    }
}
