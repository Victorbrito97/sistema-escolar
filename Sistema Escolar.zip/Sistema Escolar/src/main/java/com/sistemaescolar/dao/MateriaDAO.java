package com.sistemaescolar.dao;

import com.sistemaescolar.db.DBConnection;
import com.sistemaescolar.model.Materia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MateriaDAO {
    public void insert(Materia m) throws SQLException {
        String sql = "INSERT INTO materias(nombre) VALUES(?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, m.getNombre());
            ps.executeUpdate();
        }
    }

    public List<Materia> listAll() throws SQLException {
        List<Materia> out = new ArrayList<>();
        String sql = "SELECT id, nombre FROM materias ORDER BY id";
        try (Connection c = DBConnection.getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                out.add(new Materia(rs.getInt("id"), rs.getString("nombre")));
            }
        }
        return out;
    }
}
