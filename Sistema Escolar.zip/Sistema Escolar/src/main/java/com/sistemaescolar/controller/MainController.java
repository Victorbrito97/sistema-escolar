package com.sistemaescolar.controller;

import com.sistemaescolar.dao.AsistenciaDAO;
import com.sistemaescolar.dao.InscripcionDAO;
import com.sistemaescolar.dao.MateriaDAO;
import com.sistemaescolar.dao.PersonaDAO;
import com.sistemaescolar.model.Asistencia;
import com.sistemaescolar.model.Inscripcion;
import com.sistemaescolar.model.Materia;
import com.sistemaescolar.model.Persona;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class MainController {
    // Persona controls
    @FXML private TextField personaNombre;
    @FXML private TextField personaApellido;
    @FXML private ChoiceBox<String> personaSexo;
    @FXML private DatePicker personaFecha;
    @FXML private TextField personaRol;
    @FXML private Button personaInsertar;
    @FXML private TextArea personaArea;

    // Materia controls
    @FXML private TextField materiaNombre;
    @FXML private Button materiaInsertar;
    @FXML private TextArea materiaArea;

    // Inscripcion controls
    @FXML private TextField insPersonaId;
    @FXML private TextField insMateriaId;
    @FXML private DatePicker insFecha;
    @FXML private Button insInsertar;
    @FXML private TextArea insArea;

    // Asistencia controls
    @FXML private TextField asInscripcionId;
    @FXML private DatePicker asFecha;
    @FXML private CheckBox asPresente;
    @FXML private Button asInsertar;
    @FXML private TextArea asArea;

    private final PersonaDAO personaDAO = new PersonaDAO();
    private final MateriaDAO materiaDAO = new MateriaDAO();
    private final InscripcionDAO insDAO = new InscripcionDAO();
    private final AsistenciaDAO asDAO = new AsistenciaDAO();

    @FXML
    public void initialize() {
        personaSexo.getItems().addAll("M", "F", "Otro");
        personaFecha.setValue(LocalDate.of(2000,1,1));
        insFecha.setValue(LocalDate.now());
        asFecha.setValue(LocalDate.now());

        personaInsertar.setOnAction(e -> onInsertPersona());
        materiaInsertar.setOnAction(e -> onInsertMateria());
        insInsertar.setOnAction(e -> onInsertInscripcion());
        asInsertar.setOnAction(e -> onInsertAsistencia());

        refreshAllAreas();
    }

    private void onInsertPersona() {
        try {
            Persona p = new Persona(personaNombre.getText(), personaApellido.getText(), personaSexo.getValue(), personaFecha.getValue(), personaRol.getText());
            personaDAO.insert(p);
            refreshPersonas();
        } catch (SQLException ex) { showError(ex); }
    }

    private void onInsertMateria() {
        try {
            Materia m = new Materia(materiaNombre.getText());
            materiaDAO.insert(m);
            refreshMaterias();
        } catch (SQLException ex) { showError(ex); }
    }

    private void onInsertInscripcion() {
        try {
            int pid = Integer.parseInt(insPersonaId.getText());
            int mid = Integer.parseInt(insMateriaId.getText());
            Inscripcion i = new Inscripcion(pid, mid, insFecha.getValue());
            insDAO.insert(i);
            refreshInscripciones();
        } catch (Exception ex) { showError(ex); }
    }

    private void onInsertAsistencia() {
        try {
            int iid = Integer.parseInt(asInscripcionId.getText());
            boolean presente = asPresente.isSelected();
            Asistencia a = new Asistencia(iid, asFecha.getValue(), presente);
            asDAO.insert(a);
            refreshAsistencias();
        } catch (Exception ex) { showError(ex); }
    }

    private void refreshAllAreas() {
        refreshPersonas();
        refreshMaterias();
        refreshInscripciones();
        refreshAsistencias();
    }

    private void refreshPersonas() {
        try {
            List<Persona> list = personaDAO.listAll();
            StringBuilder sb = new StringBuilder();
            for (Persona p : list) sb.append(p).append('\n');
            personaArea.setText(sb.toString());
        } catch (SQLException e) { showError(e); }
    }

    private void refreshMaterias() {
        try {
            List<Materia> list = materiaDAO.listAll();
            StringBuilder sb = new StringBuilder();
            for (Materia m : list) sb.append(m).append('\n');
            materiaArea.setText(sb.toString());
        } catch (SQLException e) { showError(e); }
    }

    private void refreshInscripciones() {
        try {
            List<Inscripcion> list = insDAO.listAll();
            StringBuilder sb = new StringBuilder();
            for (Inscripcion i : list) sb.append(i).append('\n');
            insArea.setText(sb.toString());
        } catch (SQLException e) { showError(e); }
    }

    private void refreshAsistencias() {
        try {
            List<Asistencia> list = asDAO.listAll();
            StringBuilder sb = new StringBuilder();
            for (Asistencia a : list) sb.append(a).append('\n');
            asArea.setText(sb.toString());
        } catch (SQLException e) { showError(e); }
    }

    private void showError(Exception e) {
        Alert a = new Alert(Alert.AlertType.ERROR, e.getMessage(), ButtonType.OK);
        a.setHeaderText("Error");
        a.showAndWait();
    }
}
