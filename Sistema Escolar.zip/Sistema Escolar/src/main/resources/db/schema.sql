-- Script de creación de base de datos y tablas para Sistema Escolar
-- Ejecutar en MariaDB/MySQL (ajusta el usuario)

CREATE DATABASE IF NOT EXISTS sistema_escolar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_escolar;

CREATE TABLE IF NOT EXISTS persona_escuela (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  sexo VARCHAR(10),
  fecha_nacimiento DATE,
  rol VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS materias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL
);

CREATE TABLE IF NOT EXISTS inscripciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  persona_id INT NOT NULL,
  materia_id INT NOT NULL,
  fecha DATE,
  FOREIGN KEY (persona_id) REFERENCES persona_escuela(id) ON DELETE CASCADE,
  FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS asistencias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  inscripcion_id INT NOT NULL,
  fecha DATE,
  presente BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (inscripcion_id) REFERENCES inscripciones(id) ON DELETE CASCADE
);
